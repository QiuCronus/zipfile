from flask import Flask, request, jsonify

webapp = Flask(__name__)

from .loader import Loader
from .version import version
from .utils import LoggerFactory

normalize_args = lambda data: {
    k: v[0] if isinstance(v, list) else v for k, v in dict(data).items()
}

Logger = LoggerFactory.initialize("TRClient")
plugin_loader = Loader.instance()


def reply(code, msg):
    Logger.debug(f"code: {code}, msg: {msg}")
    return jsonify({"code": code, "msg": msg})


@webapp.route("/versions", methods=["GET"])
def show_version():
    return version


@webapp.route("/plugin/start", methods=["GET"])
def start_plugin():
    Logger.debug("start_plugin.")
    args = normalize_args(request.args)

    plugin = args.get("name", None)
    config = args.get("config", None)
    if not plugin or not config:
        return reply(400, "parameter can not be empty.")
    try:
        uid = plugin_loader.start_plugin(plugin, config)
        return reply(200, uid)
    except Exception as err:
        return reply(400, str(err))


@webapp.route("/plugin/stop", methods=["GET"])
def stop_plugin():
    Logger.debug("stop_plugin.")
    args = normalize_args(request.args)
    uid = args.get("uid", None)
    if not uid:
        return reply(400, "parameter can not be empty.")
    try:
        plugin_loader.stop_plugin(uid)
        return reply(200, "stopped")
    except Exception as err:
        return reply(400, str(err))


@webapp.route("/plugin/status", methods=["GET"])
def status_plugin():
    Logger.debug("status_plugin.")
    info = plugin_loader.status_plugin()
    return reply(200, info)


@webapp.route("/plugin/upgrade", methods=["GET"])
def upgrade_plugin():
    Logger.debug("upgrade_plugin.")
    args = normalize_args(request.args)
    uid = args.get("uid", None)
    plugin = args.get("name", None)
    config = args.get("config", None)
    if not plugin or not config or not uid:
        return reply(400, "parameter can not be empty.")
    try:
        n_uid = plugin_loader.upgrade_plugin(uid, plugin, config)
        return reply(200, n_uid)
    except Exception as err:
        return reply(400, str(err))


@webapp.route("/plugin/drop", methods=["GET"])
def drop_plugin():
    Logger.debug("drop_plugin.")
    args = normalize_args(request.args)
    uid = args.get("uid", None)
    if not uid:
        return reply(400, "parameter can not be empty.")
    try:
        plugin_loader.drop_plugin(uid)
        return reply(200, "dropped")
    except Exception as err:
        return reply(400, str(err))


@webapp.route("/plugin/shutdown", methods=["GET"])
def shutdown():
    Logger.debug("shutdown ...")
    plugin_loader.shutdown()
    return reply(200, "done.")


def start_app(host="127.0.0.1", port=9094):
    try:
        Logger.debug(f"start app on {host}:{port}.")
        plugin_loader.on_started()
        webapp.run(host=host, port=port)
    except:
        pass
    finally:
        plugin_loader.on_destroy()
