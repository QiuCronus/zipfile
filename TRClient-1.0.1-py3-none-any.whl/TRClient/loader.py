import os
import sys
from threading import Lock

from .models import IPlugins
from .sqlite import SQLiteHelper
from .utils import DataUtils, ConfigUtils, TimeUtils, LoggerFactory

Logger = LoggerFactory.initialize("TRClient")


class Loader:
    _instance_lock = Lock()
    _update_lock = Lock()
    _activate_plugins = {}
    _database = SQLiteHelper("plugin.db")

    @classmethod
    def instance(cls):
        if not hasattr(cls, "_instance"):
            with Loader._instance_lock:
                if not hasattr(cls, "_instance"):
                    Loader._instance = Loader()
        return Loader._instance

    def on_started(self):
        self._database._init()
        for row in self._database.query_enable_plugins():
            self.start_plugin(plugin=row["name"], config=row["config"])

    def on_destroy(self):
        self.shutdown()

    def start_plugin(self, plugin, config):
        Logger.debug(f"start plugin: {plugin} with {config}")

        cfg = os.path.join(os.getcwd(), "configs", config)
        if not os.path.exists(cfg):
            raise FileNotFoundError(f"No such file: {config}")

        with open(cfg, "rb") as fd:
            uid = DataUtils.get_md5(fd.read())

        if not uid:
            raise RuntimeError("calc uid failed.")

        if uid in self._activate_plugins.keys():
            raise RuntimeError("plugin already started")

        conf = ConfigUtils.load_yml_config(cfg)
        if not conf:
            raise RuntimeError("load config failed.")

        module = f"plugins.{plugin}"
        try:
            clazz = DataUtils.load_object(module)
            if not issubclass(clazz, IPlugins):
                raise ValueError("plugin must be extend `IPlugins`.")

            obj = clazz(name=uid, config=conf)
            obj.start()

        except Exception as err:
            raise RuntimeError(err)
        else:
            with self._update_lock:
                self._activate_plugins[uid] = {
                    "UID": uid,
                    "config": config,
                    "inst":   obj,
                    "plugin": plugin,
                    "start":  TimeUtils.timestamp(),
                }
                self._database.insert(uid, plugin, config)
                self._database.plugin_started(uid)

            return uid

    def stop_plugin(self, uid):
        Logger.debug(f"stop plugin {uid}")
        if uid not in self._activate_plugins.keys():
            raise RuntimeError("plugin not started.")

        with self._update_lock:
            values = self._activate_plugins.pop(uid)

            inst = values["inst"]
            inst.shutdown()
            inst.join()
            self._database.plugin_stopped(uid)

            module = values["plugin"]
            module = ".".join(module.split(".")[:-1])
            module = f"plugins.{module}"
            if module in sys.modules:
                sys.modules.pop(module)

    def status_plugin(self):
        return [
            f"UID: {uid}, Plugin: {items['plugin']}, Config: {items['config']}, Start: {items['start']}"
            for uid, items in self._activate_plugins.items()
        ]

    def upgrade_plugin(self, uid, plugin, config):
        Logger.debug(f"upgrade plugin {uid}, {plugin}, {config}")
        self.stop_plugin(uid)
        self.drop_plugin(uid, should_delete=False)
        return self.start_plugin(plugin, config)

    def drop_plugin(self, uid, should_delete=True):
        Logger.debug(f"drop plugin: {uid}")
        if should_delete:
            try:
                self.stop_plugin(uid)
            except:
                pass
        self._database.delete(uid)

    def shutdown(self):
        Logger.debug("shutdown ...")
        for uid in self._activate_plugins.keys():
            self.stop_plugin(uid=uid)
