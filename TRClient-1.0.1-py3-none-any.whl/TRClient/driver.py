import pymysql


class MySQLDriver(object):
    def __init__(self, host=None, user=None, password="", database=None, port=0):
        self.host = host or "localhost"
        self.port = port or 3306
        self.user = user
        self.password = password
        self.database = database
        self.connection = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.connection:
            self.connection.close()
        return False

    def connect(self):
        self.connection = pymysql.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            db=self.database,
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
        )

    def is_connected(self):
        try:
            self.connection.ping()
            return True
        except:
            return False
