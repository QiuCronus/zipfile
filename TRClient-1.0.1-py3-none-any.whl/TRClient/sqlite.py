import sqlite3
import time


class SQLiteHelper(object):
    DISABLED = 0
    ENABLED = 1
    PENDING = 2
    RUNNING = 3

    def __init__(self, database: str):
        database = database or ":memory:"
        self.connection = sqlite3.connect(database, check_same_thread=False)
        self.connection.row_factory = lambda cursor, row: {
            col[0]: row[idx] for idx, col in enumerate(cursor.description)
        }
        init_sql = (
            "CREATE TABLE IF NOT EXISTS `plugin`("
            "`uid` VARCHAR(32) NOT NULL, "
            "`name` VARCHAR(32) NOT NULL, "
            "`status` INT(2) DEFAULT 0,"
            "`config` VARCHAR(128) NOT NULL, "
            "`update_time` INT(11) DEFAULT 0,"
            " UNIQUE(uid));"
        )
        self.connection.execute(init_sql)
        self.connection.commit()

    def _init(self):
        q = f"UPDATE `plugin` SET `status` = {SQLiteHelper.PENDING} WHERE `status` = {SQLiteHelper.RUNNING};"
        self.connection.execute(q)
        self.connection.commit()

    def insert(self, uid: str, plugin: str, config: str):
        if self.query(uid):
            self.delete(uid)

        q = "INSERT INTO `plugin` (`uid`,`name`,`status`, `config`, `update_time`) VALUES (?,?,?,?,?);"
        self.connection.execute(q, (uid, plugin, 1, config, int(time.time())))
        self.connection.commit()

    def delete(self, uid: str):
        q = "DELETE FROM `plugin` WHERE `uid` = ?;"
        self.connection.execute(q, (uid,))
        self.connection.commit()

    def querys(self):
        q = "SELECT `uid`, `name`, `config` FROM `plugin`;"
        return [row for row in self.connection.execute(q)]

    def query(self, uid):
        q = "SELECT `name` FROM `plugin` WHERE `uid` = ?;"
        try:
            cursor = self.connection.execute(q, (uid,))
            r = cursor.fetchone()
            return True if r and "name" in r else False
        except:
            return False

    def query_enable_plugins(self):
        q = f"SELECT `uid`, `name`, `config` FROM `plugin` WHERE `status` > {SQLiteHelper.DISABLED};"
        return [row for row in self.connection.execute(q)]

    def update_plugin_status(self, uid, status):
        q = f"UPDATE `plugin` SET `status` = {status} WHERE `uid` = '{uid}';"
        self.connection.execute(q)
        self.connection.commit()

    def plugin_started(self, uid):
        self.update_plugin_status(uid, SQLiteHelper.RUNNING)

    def plugin_stopped(self, uid):
        self.update_plugin_status(uid, SQLiteHelper.PENDING)

    def plugin_disabled(self, uid):
        self.update_plugin_status(uid, SQLiteHelper.DISABLED)

    def plugin_enabled(self, uid):
        self.update_plugin_status(uid, SQLiteHelper.ENABLED)
